$.extend($.fn.edatagrid.defaults.destroyMsg, {
	norecord:{
		title:'警告',
		msg:'请先选择记录后再进行删除。'
	},
	confirm:{
		title:'删除确认',
		msg:'是否真的删除该项记录？'
	}
});