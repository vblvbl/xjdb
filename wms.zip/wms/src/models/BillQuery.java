package models;

/**
 * 单据查询参数对象
 *
 */
public class BillQuery {
	private String code;
	private String codeFrom;
	private String codeTo;
	private String dateFrom;
	private String dateTo;
	private Integer intercourseId;
	private Integer depotId;
	private Integer depot2Id;
	private Integer workerId;
	private Integer stockType;
	private String shWorker;
	private Integer moneyType;
	private String goodType;
	
	public String getShWorker() {
		return shWorker;
	}
	public void setShWorker(String shWorker) {
		this.shWorker = shWorker;
	}
	public Integer getWorkerId() {
		return workerId;
	}
	public void setWorkerId(Integer workerId) {
		this.workerId = workerId;
	}
	public String getCodeFrom() {
		return codeFrom;
	}
	public void setCodeFrom(String codeFrom) {
		this.codeFrom = codeFrom;
	}
	public String getCodeTo() {
		return codeTo;
	}
	public void setCodeTo(String codeTo) {
		this.codeTo = codeTo;
	}
	public String getDateFrom() {
		return dateFrom;
	}
	public void setDateFrom(String dateFrom) {
		this.dateFrom = dateFrom;
	}
	public String getDateTo() {
		return dateTo;
	}
	public void setDateTo(String dateTo) {
		this.dateTo = dateTo;
	}
	public Integer getIntercourseId() {
		return intercourseId;
	}
	public void setIntercourseId(Integer intercourseId) {
		this.intercourseId = intercourseId;
	}
	public Integer getDepotId() {
		return depotId;
	}
	public void setDepotId(Integer depotId) {
		this.depotId = depotId;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Integer getDepot2Id() {
		return depot2Id;
	}
	public void setDepot2Id(Integer depot2Id) {
		this.depot2Id = depot2Id;
	}
	public Integer getStockType() {
		return stockType;
	}
	public void setStockType(Integer stockType) {
		this.stockType = stockType;
	}
	public Integer getMoneyType() {
		return moneyType;
	}
	public void setMoneyType(Integer moneyType) {
		this.moneyType = moneyType;
	}
	public String getGoodType() {
		return goodType;
	}
	public void setGoodType(String goodType) {
		this.goodType = goodType;
	}
}
