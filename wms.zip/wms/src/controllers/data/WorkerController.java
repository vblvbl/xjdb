package controllers.data;

import java.util.Map;

import models.Worker;

import com.et.mvc.JsonView;
import com.et.mvc.View;

import controllers.ApplicationController;

public class WorkerController extends ApplicationController{
	public void index(){
		
	}
	
	public View getItems() throws Exception{
		return new JsonView(Worker.findAll(Worker.class));
	}
	
	public View save(Worker item) throws Exception{
		item.save();
		return new JsonView(item);
	}
	
	public View update(int id, Map<String,Object> params) throws Exception{
		Worker item = Worker.find(Worker.class, id);
		item = Worker.updateModel(item, params);
		item.save();
		return new JsonView(item);
	}
	
	public View destroy(int id) throws Exception{
		Worker item = Worker.find(Worker.class, id);
		item.destroy();
		return new JsonView("success:true");
	}
}
