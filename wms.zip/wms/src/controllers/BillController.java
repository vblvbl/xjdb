package controllers;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import models.Bill;
import models.BillDetail;
import models.BillQuery;
import models.Good;
import models.GoodType;
import models.Intercourse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import rbac.models.User;
import service.CheckService;

import com.et.mvc.JsonView;
import com.et.mvc.View;

public class BillController extends ApplicationController{
	public View getInitDetails() throws Exception{
		List<Map<String,Object>> footer = new ArrayList<Map<String,Object>>();
		Map<String,Object> fitem = new HashMap<String,Object>();
		fitem.put("name", "合计");
		fitem.put("billCount", 0);
		fitem.put("billCost", 0);
		footer.add(fitem);
		
		Map<String,Object> result = new HashMap<String,Object>();
		result.put("total", 0);
		result.put("rows", new Object[]{});
		result.put("footer", footer);
		return new JsonView(result);
	}
	
	public View getBillDetails(int billId) throws Exception{
		Bill bill = Bill.find(Bill.class, billId);
		
		List<Map<String,Object>> items = new ArrayList<Map<String,Object>>();
		for(BillDetail billDetail: bill.getBillDetails()){
			Map<String,Object> item = new HashMap<String,Object>();
			item.put("id", billDetail.getGoodId());
			Good good = billDetail.getGood();
			if (good != null){
				item.put("code", good.getCode());
				item.put("name", good.getName());
				item.put("spec", good.getSpec());
				item.put("model", good.getModel());
				item.put("color", good.getColor());
				item.put("unit", good.getUnit());
				item.put("piece", good.getPiece());
				item.put("square", good.getSquare());
			}
			item.put("billCount", billDetail.getBillCount());
			item.put("billPrice", billDetail.getBillPrice());
			item.put("billCost", billDetail.getBillCost());
			item.put("billDetailId", billDetail.getBillDetailId());
			item.put("jian", billDetail.getJian());
			item.put("pian", billDetail.getPian());
			items.add(item);
		}
		
		List<Map<String,Object>> footer = new ArrayList<Map<String,Object>>();
		Map<String,Object> fitem = new HashMap<String,Object>();
		fitem.put("name", "合计");
		fitem.put("billCount", bill.getBillCount());
		fitem.put("billCost", bill.getBillCost());
		footer.add(fitem);
		
		Map<String,Object> result = new HashMap<String,Object>();
		result.put("total", items.size());
		result.put("rows", items);
		result.put("footer", footer);
		return new JsonView(result);
	}
	/*public View excelToDisk (int id) throws Exception{
		Bill bill = Bill.find(Bill.class, id);
		DecimalFormat df = new DecimalFormat("#.00");
		Intercourse ic = Intercourse.find(Intercourse.class, bill.getIntercourseId());
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet("单据");
		sheet.setColumnWidth((short) 0, (short) (3000));
		sheet.setColumnWidth((short) 1, (short) (3000));
		sheet.setColumnWidth((short) 2, (short) (3000));
		sheet.setColumnWidth((short) 3, (short) (2500));
		sheet.setColumnWidth((short) 4, (short) (2500));
		sheet.setColumnWidth((short) 5, (short) (2000));
		sheet.setColumnWidth((short) 6, (short) (3000));
		sheet.setColumnWidth((short) 7, (short) (3000));
		sheet.setMargin(HSSFSheet.BottomMargin,0.1);// 页边距（下）  
		sheet.setMargin(HSSFSheet.LeftMargin,0.1);// 页边距（左）  
		sheet.setMargin(HSSFSheet.RightMargin,0.1);// 页边距（右）  
		sheet.setMargin(HSSFSheet.TopMargin,0.1);// 页边距（上）
		sheet.setDefaultRowHeight((short)300);
		HSSFRow row = sheet.createRow((int) 0);
		HSSFCellStyle titleStyle = wb.createCellStyle();
		HSSFFont titleFont = wb.createFont();
		titleFont.setFontName(HSSFFont.FONT_ARIAL);//字体
		titleFont.setFontHeightInPoints((short) 20);//字号 
		titleFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		titleStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER); 
		titleStyle.setFont(titleFont);
		HSSFCell cell = row.createCell((short) 3);
		cell.setCellValue("鑫  佳  地  板  超  市");
		cell.setCellStyle(titleStyle);
		HSSFCellStyle nameStyle = wb.createCellStyle();
		HSSFFont nameFont = wb.createFont();
		nameFont.setFontName(HSSFFont.FONT_ARIAL);//字体
		nameFont.setFontHeightInPoints((short) 9);//字号 
		//nameFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		nameStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT); 
		nameStyle.setFont(nameFont);
		row = sheet.createRow((int) 1);
		cell = row.createCell((short) 0);
		cell.setCellValue("客户名称：");
 		cell.setCellStyle(nameStyle);
// 		row = sheet.createRow((int) 1);
 		cell = row.createCell((short) 1);
		cell.setCellValue(ic.getShortName());
		cell = row.createCell((short) 2);
		cell.setCellValue("客户电话：");
 		cell.setCellStyle(nameStyle);
// 		row = sheet.createRow((int) 1);
 		cell = row.createCell((short) 3);
		cell.setCellValue(ic.getPhone());
// 		cell.setCellStyle(nameStyle);
		cell = row.createCell((short) 6);
		cell.setCellValue("打印日期：");
 		cell.setCellStyle(nameStyle);
 		cell = row.createCell((short) 7);
		cell.setCellValue(DateFormat.getDateInstance().format(new Date()));
 		cell.setCellStyle(nameStyle);
 		HSSFCellStyle uldStyle = wb.createCellStyle();
 		uldStyle.setBorderTop(HSSFCellStyle.BORDER_MEDIUM);
 		uldStyle.setBorderLeft(HSSFCellStyle.BORDER_MEDIUM);
 		uldStyle.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);
 		uldStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT); 
 		HSSFCellStyle urdStyle = wb.createCellStyle();
 		urdStyle.setBorderTop(HSSFCellStyle.BORDER_MEDIUM);
 		urdStyle.setBorderRight(HSSFCellStyle.BORDER_MEDIUM);
 		urdStyle.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);
 		urdStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT); 
 		HSSFCellStyle udStyle = wb.createCellStyle();
 		udStyle.setBorderTop(HSSFCellStyle.BORDER_MEDIUM);
 		udStyle.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);
 		udStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT); 
 		
 		row = sheet.createRow((int) 2);
 		cell = row.createCell((short) 0);
		cell.setCellValue("散户：");
 		cell.setCellStyle(nameStyle);
 		cell = row.createCell((short) 1);
		cell.setCellValue(bill.getShWorker());
		cell = row.createCell((short) 2);
		cell.setCellValue("备注：");
 		cell.setCellStyle(nameStyle);
 		cell = row.createCell((short) 3);
		cell.setCellValue(bill.getRemark());
		cell = row.createCell((short) 6);
		
		
 		row = sheet.createRow((int) 3);
 		cell = row.createCell((short) 0);
 		cell.setCellValue("品牌");
 		cell.setCellStyle(urdStyle);
// 		cell = row.createCell((short) 1);
// 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 1);
 		cell.setCellValue("型号");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 3);
 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 2);
 		cell.setCellValue("件");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 5);
 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 3);
 		cell.setCellValue("片");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 7);
 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 4);
 		cell.setCellValue("平方");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 9);
 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 5);
 		cell.setCellValue("单价");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 11);
 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 6);
 		cell.setCellValue("金额");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 13);
 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 7);
 		cell.setCellValue("付款方式");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 15);
 		cell.setCellStyle(urdStyle);
 		String money ="";
		if(bill.getMoneyType() != null && bill.getMoneyType() == 0){
			money = "未付";
		}else if(bill.getMoneyType() != null && bill.getMoneyType() == 1){
			money = "已付";
		}else if(bill.getMoneyType() != null && bill.getMoneyType() == 2){
			money = "代收";
		}else if(bill.getMoneyType() != null && bill.getMoneyType() == 3){
			money = "其他";
		}
		BigDecimal totalPrice = new BigDecimal("0");
 		for(int i=0;i<bill.getBillDetails().size()+1;i++){
 			row = sheet.createRow((int) i+4);
 			if(i ==bill.getBillDetails().size()){
 				row.setHeight((short)500);
 	 			cell = row.createCell((short) 0);
 	 	 		cell.setCellStyle(urdStyle);
// 	 	 		cell = row.createCell((short) 1);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 1);
 	 	 		cell.setCellStyle(urdStyle);
// 	 	 		cell = row.createCell((short) 3);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 2);
 	 	 		cell.setCellStyle(urdStyle);
// 	 	 		cell = row.createCell((short) 5);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 3);
 	 	 		cell.setCellStyle(urdStyle);
// 	 	 		cell = row.createCell((short) 7);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 4);
 	 	 		cell.setCellStyle(urdStyle);
// 	 	 		cell = row.createCell((short) 9);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 5);
 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell.setCellValue("合计：");
// 	 	 		cell = row.createCell((short) 11);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 6);
 	 	 		//cell.setCellValue(String.format("%.f", bd.getBillCost()));
 	 	 		cell.setCellValue(Math.rint(totalPrice.doubleValue()));
 	 	 		//cell.setCellValue(Math.rint(bd.getBillCost().doubleValue()));
 	 	 		cell.setCellStyle(urdStyle);
// 	 	 		cell = row.createCell((short) 13);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 7);
 	 	 		cell.setCellStyle(urdStyle);
 	 	 		break;
 	 		}
 			BillDetail bd = bill.getBillDetails().get(i);
 			row = sheet.createRow((int) i+4);
 			row.setHeight((short)500);
 			Good good = bd.getGood();
 			GoodType gt = good.getGoodType();
 			cell = row.createCell((short) 0);
 	 		cell.setCellValue(gt.getName());
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 1);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 1);
 	 		cell.setCellValue(good.getName());
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 3);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 2);
 	 		cell.setCellValue(bd.getJian());
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 5);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 3);
 	 		cell.setCellValue(bd.getPian());
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 7);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 4);
 	 		cell.setCellValue(String.format("%.2f", bd.getBillCount()));
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 9);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 5);
 	 		cell.setCellValue(String.format("%.2f", bd.getBillPrice()));
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 11);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 6);
 	 		//cell.setCellValue(String.format("%.f", bd.getBillCost()));
 	 		cell.setCellValue(String.format("%.2f", bd.getBillCost()));
 	 		//cell.setCellValue(Math.rint(bd.getBillCost().doubleValue()));
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 13);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 7);
 	 		cell.setCellValue(money);
 	 		cell.setCellStyle(urdStyle);
 	 		totalPrice = totalPrice.add(bd.getBillCost());
// 	 		cell = row.createCell((short) 15);
// 	 		cell.setCellStyle(urdStyle);
		}
// 		row = sheet.createRow((int) bill.getBillDetails().size()+3);
// 		cell = row.createCell((short) 10);
//	 	cell.setCellValue("库房电话：1234567");
//	 	cell.setCellStyle(nameStyle);
 		
 		
// 		row = sheet.createRow((int) bill.getBillDetails().size()+3);
// 		cell = row.createCell((short) 5);
//	 	cell.setCellValue("总计： ");
//	 	cell.setCellStyle(nameStyle);
//	 	cell = row.createCell((short) 6);
//	 	cell.setCellValue(Math.rint(totalPrice.doubleValue()));
//	 	cell.setCellStyle(nameStyle);
 		row = sheet.createRow((int) bill.getBillDetails().size()+5);
 		cell = row.createCell((short) 0);
	 	cell.setCellValue("注： ");
	 	cell.setCellStyle(nameStyle);
	 	cell = row.createCell((short) 1);
	 	cell.setCellValue(" 一.买方点货，验货，卖方默认买房已验货，不接受安装后以错误名义要求赔偿。");
	 	cell.setCellStyle(nameStyle);
	 	row = sheet.createRow((int) bill.getBillDetails().size()+6);
	 	cell = row.createCell((short) 1);
	 	cell.setCellValue("  二.剩货请在20日内返回，散票包好，以免运输过程中造成不必要的损失。");
	 	cell.setCellStyle(nameStyle);
	 	row = sheet.createRow((int) bill.getBillDetails().size()+7);
	 	cell = row.createCell((short) 1);
	 	cell.setCellValue("  三.磕坏,划痕等影响二次销售的不予退货。");
	 	cell.setCellStyle(nameStyle);
	 	row = sheet.createRow((int) bill.getBillDetails().size()+8);
	 	cell = row.createCell((short) 1);
	 	cell.setCellValue("  四.现货与样板有色差，以现货为主。");
	 	cell.setCellStyle(nameStyle);
	 	HSSFCellStyle bomStyle = wb.createCellStyle();
		HSSFFont bomFont = wb.createFont();
		bomFont.setFontName(HSSFFont.FONT_ARIAL);//字体
		bomFont.setFontHeightInPoints((short) 13);//字号 
		//nameFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		bomStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT); 
		bomStyle.setFont(bomFont);
	 	row = sheet.createRow((int) bill.getBillDetails().size()+9);
	 	cell = row.createCell((short) 0);
	 	cell.setCellValue("  实木地板,实木多层地板,运动地板,静电地板,拼花  ");
	 	cell.setCellStyle(bomStyle);
	 	cell = row.createCell((short) 5);
	 	cell.setCellValue("  库房电话：5280012");
	 	cell.setCellStyle(bomStyle);
 		boolean flag = true;
		try
		{	
			Date currentTime = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			String dateString = formatter.format(currentTime);
			File file = new File("E:/xinjia/"+dateString+"/");
			if(!file.exists()){
				file.mkdirs();
			}
			FileOutputStream fout = new FileOutputStream("E:/xinjia/"+dateString+"/"+bill.getCode()+".xls");
			wb.write(fout);
			fout.close();
		}
		catch (Exception e)
		{
			flag = false;
			e.printStackTrace();
		}
		Map<String,Object> result = new HashMap<String,Object>();
		if (flag){
			result.put("success", true);
			result.put("msg", "导出成功!");
			result.put("billId", id);
		} else {
			result.put("failure", true);
			result.put("msg", "导出失败!");
		}
		return new JsonView(result);
	}*/
	
	public View excelToDisk (int id) throws Exception{
		Bill bill = Bill.find(Bill.class, id);
		DecimalFormat df = new DecimalFormat("#.00");
		Intercourse ic = Intercourse.find(Intercourse.class, bill.getIntercourseId());
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet("单据");
		sheet.setColumnWidth((short) 0, (short) (3000));
		sheet.setColumnWidth((short) 1, (short) (3000));
		sheet.setColumnWidth((short) 2, (short) (3000));
		sheet.setColumnWidth((short) 3, (short) (2500));
		sheet.setColumnWidth((short) 4, (short) (2500));
		sheet.setColumnWidth((short) 5, (short) (2000));
		sheet.setColumnWidth((short) 6, (short) (3000));
		sheet.setColumnWidth((short) 7, (short) (3000));
		sheet.setMargin(HSSFSheet.BottomMargin,0.1);// 页边距（下）  
		sheet.setMargin(HSSFSheet.LeftMargin,0.1);// 页边距（左）  
		sheet.setMargin(HSSFSheet.RightMargin,0.1);// 页边距（右）  
		sheet.setMargin(HSSFSheet.TopMargin,0.1);// 页边距（上）
		sheet.setDefaultRowHeight((short)300);
		HSSFRow row = sheet.createRow((int) 0);
		HSSFCellStyle titleStyle = wb.createCellStyle();
		HSSFFont titleFont = wb.createFont();
		titleFont.setFontName(HSSFFont.FONT_ARIAL);//字体
		titleFont.setFontHeightInPoints((short) 20);//字号 
		titleFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		titleStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER); 
		titleStyle.setFont(titleFont);
		
		HSSFCellStyle nameStyle = wb.createCellStyle();
		HSSFFont nameFont = wb.createFont();
		nameFont.setFontName(HSSFFont.FONT_ARIAL);//字体
		nameFont.setFontHeightInPoints((short) 9);//字号 
		//nameFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		nameStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT); 
		nameStyle.setFont(nameFont);
		
		HSSFCell cell = row.createCell((short) 2);
		cell.setCellValue("鑫  佳  地  板  超  市");
		cell.setCellStyle(titleStyle);
		cell = row.createCell((short) 5);
		cell.setCellValue(bill.getCode());
		cell.setCellStyle(nameStyle);
		
		row = sheet.createRow((int) 1);
		cell = row.createCell((short) 0);
		cell.setCellValue("客户名称：");
 		cell.setCellStyle(nameStyle);
// 		row = sheet.createRow((int) 1);
 		cell = row.createCell((short) 1);
		cell.setCellValue(ic.getShortName());
		cell = row.createCell((short) 2);
		cell.setCellValue("客户电话：");
 		cell.setCellStyle(nameStyle);
// 		row = sheet.createRow((int) 1);
 		cell = row.createCell((short) 3);
		cell.setCellValue(ic.getPhone());
// 		cell.setCellStyle(nameStyle);
		cell = row.createCell((short) 6);
		cell.setCellValue("打印日期：");
 		cell.setCellStyle(nameStyle);
 		cell = row.createCell((short) 7);
		cell.setCellValue(DateFormat.getDateInstance().format(new Date()));
 		cell.setCellStyle(nameStyle);
 		HSSFCellStyle uldStyle = wb.createCellStyle();
 		uldStyle.setBorderTop(HSSFCellStyle.BORDER_MEDIUM);
 		uldStyle.setBorderLeft(HSSFCellStyle.BORDER_MEDIUM);
 		uldStyle.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);
 		uldStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT); 
 		HSSFCellStyle urdStyle = wb.createCellStyle();
 		urdStyle.setBorderTop(HSSFCellStyle.BORDER_MEDIUM);
 		urdStyle.setBorderRight(HSSFCellStyle.BORDER_MEDIUM);
 		urdStyle.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);
 		urdStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT); 
 		HSSFCellStyle udStyle = wb.createCellStyle();
 		udStyle.setBorderTop(HSSFCellStyle.BORDER_MEDIUM);
 		udStyle.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);
 		udStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT); 
 		
 		row = sheet.createRow((int) 2);
 		cell = row.createCell((short) 0);
		cell.setCellValue("散户：");
 		cell.setCellStyle(nameStyle);
 		cell = row.createCell((short) 1);
		cell.setCellValue(bill.getShWorker());
		cell = row.createCell((short) 2);
		cell.setCellValue("备注：");
 		cell.setCellStyle(nameStyle);
 		cell = row.createCell((short) 3);
		cell.setCellValue(bill.getRemark());
		cell = row.createCell((short) 6);
		
		
 		row = sheet.createRow((int) 3);
 		cell = row.createCell((short) 0);
 		cell.setCellValue("品牌");
 		cell.setCellStyle(urdStyle);
// 		cell = row.createCell((short) 1);
// 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 1);
 		cell.setCellValue("型号");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 3);
 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 2);
 		cell.setCellValue("件");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 5);
 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 3);
 		cell.setCellValue("片");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 7);
 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 4);
 		cell.setCellValue("平方");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 9);
 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 5);
 		cell.setCellValue("单价");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 11);
 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 6);
 		cell.setCellValue("金额");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 13);
 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 7);
 		cell.setCellValue("付款方式");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 15);
 		cell.setCellStyle(urdStyle);
 		String money ="";
		if(bill.getMoneyType() != null && bill.getMoneyType() == 0){
			money = "未付";
		}else if(bill.getMoneyType() != null && bill.getMoneyType() == 1){
			money = "已付";
		}else if(bill.getMoneyType() != null && bill.getMoneyType() == 2){
			money = "代收";
		}else if(bill.getMoneyType() != null && bill.getMoneyType() == 3){
			money = "其他";
		}
		BigDecimal totalPrice = new BigDecimal("0");
 		for(int i=0;i<bill.getBillDetails().size()+1;i++){
 			row = sheet.createRow((int) i+4);
 			if(i ==bill.getBillDetails().size()){
 				row.setHeight((short)500);
 	 			cell = row.createCell((short) 0);
 	 	 		cell.setCellStyle(urdStyle);
// 	 	 		cell = row.createCell((short) 1);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 1);
 	 	 		cell.setCellStyle(urdStyle);
// 	 	 		cell = row.createCell((short) 3);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 2);
 	 	 		cell.setCellStyle(urdStyle);
// 	 	 		cell = row.createCell((short) 5);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 3);
 	 	 		cell.setCellStyle(urdStyle);
// 	 	 		cell = row.createCell((short) 7);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 4);
 	 	 		cell.setCellStyle(urdStyle);
// 	 	 		cell = row.createCell((short) 9);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 5);
 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell.setCellValue("合计：");
// 	 	 		cell = row.createCell((short) 11);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 6);
 	 	 		//cell.setCellValue(String.format("%.f", bd.getBillCost()));
 	 	 		cell.setCellValue(Math.rint(totalPrice.doubleValue()));
 	 	 		//cell.setCellValue(Math.rint(bd.getBillCost().doubleValue()));
 	 	 		cell.setCellStyle(urdStyle);
// 	 	 		cell = row.createCell((short) 13);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 7);
 	 	 		cell.setCellStyle(urdStyle);
 	 	 		break;
 	 		}
 			BillDetail bd = bill.getBillDetails().get(i);
 			row = sheet.createRow((int) i+4);
 			row.setHeight((short)500);
 			Good good = bd.getGood();
 			GoodType gt = good.getGoodType();
 			cell = row.createCell((short) 0);
 	 		cell.setCellValue(gt.getName());
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 1);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 1);
 	 		cell.setCellValue(good.getName());
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 3);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 2);
 	 		cell.setCellValue(bd.getJian());
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 5);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 3);
 	 		cell.setCellValue(bd.getPian());
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 7);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 4);
 	 		cell.setCellValue(String.format("%.2f", bd.getBillCount()));
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 9);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 5);
 	 		cell.setCellValue(String.format("%.2f", bd.getBillPrice()));
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 11);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 6);
 	 		//cell.setCellValue(String.format("%.f", bd.getBillCost()));
 	 		cell.setCellValue(String.format("%.2f", bd.getBillCost()));
 	 		//cell.setCellValue(Math.rint(bd.getBillCost().doubleValue()));
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 13);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 7);
 	 		cell.setCellValue(money);
 	 		cell.setCellStyle(urdStyle);
 	 		totalPrice = totalPrice.add(bd.getBillCost());
// 	 		cell = row.createCell((short) 15);
// 	 		cell.setCellStyle(urdStyle);
		}
// 		row = sheet.createRow((int) bill.getBillDetails().size()+3);
// 		cell = row.createCell((short) 10);
//	 	cell.setCellValue("库房电话：1234567");
//	 	cell.setCellStyle(nameStyle);
 		
 		
// 		row = sheet.createRow((int) bill.getBillDetails().size()+3);
// 		cell = row.createCell((short) 5);
//	 	cell.setCellValue("总计： ");
//	 	cell.setCellStyle(nameStyle);
//	 	cell = row.createCell((short) 6);
//	 	cell.setCellValue(Math.rint(totalPrice.doubleValue()));
//	 	cell.setCellStyle(nameStyle);
 		row = sheet.createRow((int) bill.getBillDetails().size()+5);
 		cell = row.createCell((short) 0);
	 	cell.setCellValue("注： ");
	 	cell.setCellStyle(nameStyle);
	 	cell = row.createCell((short) 1);
	 	cell.setCellValue(" 一.买方须认真点货，验货，卖方默认买方已验收，不接受以错误名义要求赔偿。");
	 	cell.setCellStyle(nameStyle);
	 	row = sheet.createRow((int) bill.getBillDetails().size()+6);
	 	cell = row.createCell((short) 1);
	 	cell.setCellValue("  二.退货在购买15日内返回，散片带好包装，无包装不予退货");
	 	cell.setCellStyle(nameStyle);
	 	row = sheet.createRow((int) bill.getBillDetails().size()+7);
	 	cell = row.createCell((short) 1);
	 	cell.setCellValue("  三.运输，安装过程中，碰坏划坏等影响二次销售的，不予退货。");
	 	cell.setCellStyle(nameStyle);
	 	row = sheet.createRow((int) bill.getBillDetails().size()+8);
	 	cell = row.createCell((short) 1);
	 	cell.setCellValue("  四.现货与样板有色差，以现货为主。");
	 	cell.setCellStyle(nameStyle);
	 	HSSFCellStyle bomStyle = wb.createCellStyle();
		HSSFFont bomFont = wb.createFont();
		bomFont.setFontName(HSSFFont.FONT_ARIAL);//字体
		bomFont.setFontHeightInPoints((short) 13);//字号 
		//nameFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		bomStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT); 
		bomStyle.setFont(bomFont);
	 	row = sheet.createRow((int) bill.getBillDetails().size()+9);
	 	cell = row.createCell((short) 0);
	 	cell.setCellValue("  经营各种品牌地板,实木地板,多层实木、强化复合地板,抗静电地板,实木运动地板,  ");
	 	cell.setCellStyle(bomStyle);
	 	row = sheet.createRow((int) bill.getBillDetails().size()+10);
	 	cell = row.createCell((short) 0);
	 	cell.setCellValue("  塑胶体育地板,个性拼花地板,防潮膜,踢脚线,门口铝材,护角,衣柜板材。现货为主 。 ");
	 	cell.setCellStyle(bomStyle);
	 	row = sheet.createRow((int) bill.getBillDetails().size()+11);
	 	cell = row.createCell((short) 5);
	 	cell.setCellValue("  电话：5280012-0317");
	 	cell.setCellStyle(bomStyle);
	 	row = sheet.createRow((int) bill.getBillDetails().size()+12);
	 	cell = row.createCell((short) 5);
	 	cell.setCellValue("    	         18903175559");
	 	cell.setCellStyle(bomStyle);
//	 	row = sheet.createRow((int) bill.getBillDetails().size()+13);
//	 	cell = row.createCell((short) 5);
//	 	cell.setCellValue("  微信号：476067881");
//	 	cell.setCellStyle(bomStyle);
//	 	row = sheet.createRow((int) bill.getBillDetails().size()+14);
//	 	cell = row.createCell((short) 5);
//	 	cell.setCellValue("  微信号：1598455239");
//	 	cell.setCellStyle(bomStyle);
 		boolean flag = true;
		try
		{	
			Date currentTime = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			String dateString = formatter.format(currentTime);
			File file = new File("E:/xinjia/"+dateString+"/");
			if(!file.exists()){
				file.mkdirs();
			}
			FileOutputStream fout = new FileOutputStream("E:/xinjia/"+dateString+"/"+bill.getCode()+".xls");
			wb.write(fout);
			fout.close();
		}
		catch (Exception e)
		{
			flag = false;
			e.printStackTrace();
		}
		Map<String,Object> result = new HashMap<String,Object>();
		if (flag){
			result.put("success", true);
			result.put("msg", "导出成功!");
			result.put("billId", id);
		} else {
			result.put("failure", true);
			result.put("msg", "导出失败!");
		}
		return new JsonView(result);
	}
	
	
	
	
	
	public View excelClpToDisk (int id) throws Exception{
		Bill bill = Bill.find(Bill.class, id);
		DecimalFormat df = new DecimalFormat("#.00");
		Intercourse ic = Intercourse.find(Intercourse.class, bill.getIntercourseId());
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet("单据");
		sheet.setColumnWidth((short) 0, (short) (3000));
		sheet.setColumnWidth((short) 1, (short) (3000));
		sheet.setColumnWidth((short) 2, (short) (3000));
		sheet.setColumnWidth((short) 3, (short) (2500));
		sheet.setColumnWidth((short) 4, (short) (2500));
		sheet.setColumnWidth((short) 5, (short) (2000));
		sheet.setColumnWidth((short) 6, (short) (3000));
		sheet.setColumnWidth((short) 7, (short) (3000));
		sheet.setMargin(HSSFSheet.BottomMargin,0.1);// 页边距（下）  
		sheet.setMargin(HSSFSheet.LeftMargin,0.1);// 页边距（左）  
		sheet.setMargin(HSSFSheet.RightMargin,0.1);// 页边距（右）  
		sheet.setMargin(HSSFSheet.TopMargin,0.1);// 页边距（上）
		sheet.setDefaultRowHeight((short)300);
		HSSFRow row = sheet.createRow((int) 0);
		HSSFCellStyle titleStyle = wb.createCellStyle();
		HSSFFont titleFont = wb.createFont();
		titleFont.setFontName(HSSFFont.FONT_ARIAL);//字体
		titleFont.setFontHeightInPoints((short) 20);//字号 
		titleFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		titleStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER); 
		titleStyle.setFont(titleFont);
		
		HSSFCellStyle nameStyle = wb.createCellStyle();
		HSSFFont nameFont = wb.createFont();
		nameFont.setFontName(HSSFFont.FONT_ARIAL);//字体
		nameFont.setFontHeightInPoints((short) 9);//字号 
		//nameFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		nameStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT); 
		nameStyle.setFont(nameFont);
		
		HSSFCell cell = row.createCell((short) 2);
		cell.setCellValue("处理下线不合格品");
		cell.setCellStyle(titleStyle);
		cell = row.createCell((short) 5);
		cell.setCellValue(bill.getCode());
		cell.setCellStyle(nameStyle);
		
		row = sheet.createRow((int) 1);
		cell = row.createCell((short) 0);
		cell.setCellValue("客户名称：");
 		cell.setCellStyle(nameStyle);
// 		row = sheet.createRow((int) 1);
 		cell = row.createCell((short) 1);
		cell.setCellValue(ic.getShortName());
		cell = row.createCell((short) 2);
		cell.setCellValue("客户电话：");
 		cell.setCellStyle(nameStyle);
// 		row = sheet.createRow((int) 1);
 		cell = row.createCell((short) 3);
		cell.setCellValue(ic.getPhone());
// 		cell.setCellStyle(nameStyle);
		cell = row.createCell((short) 6);
		cell.setCellValue("打印日期：");
 		cell.setCellStyle(nameStyle);
 		cell = row.createCell((short) 7);
		cell.setCellValue(DateFormat.getDateInstance().format(new Date()));
 		cell.setCellStyle(nameStyle);
 		HSSFCellStyle uldStyle = wb.createCellStyle();
 		uldStyle.setBorderTop(HSSFCellStyle.BORDER_MEDIUM);
 		uldStyle.setBorderLeft(HSSFCellStyle.BORDER_MEDIUM);
 		uldStyle.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);
 		uldStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT); 
 		HSSFCellStyle urdStyle = wb.createCellStyle();
 		urdStyle.setBorderTop(HSSFCellStyle.BORDER_MEDIUM);
 		urdStyle.setBorderRight(HSSFCellStyle.BORDER_MEDIUM);
 		urdStyle.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);
 		urdStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT); 
 		HSSFCellStyle udStyle = wb.createCellStyle();
 		udStyle.setBorderTop(HSSFCellStyle.BORDER_MEDIUM);
 		udStyle.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);
 		udStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT); 
 		
 		row = sheet.createRow((int) 2);
 		cell = row.createCell((short) 0);
		cell.setCellValue("散户：");
 		cell.setCellStyle(nameStyle);
 		cell = row.createCell((short) 1);
		cell.setCellValue(bill.getShWorker());
		cell = row.createCell((short) 2);
		cell.setCellValue("备注：");
 		cell.setCellStyle(nameStyle);
 		cell = row.createCell((short) 3);
		cell.setCellValue(bill.getRemark());
		cell = row.createCell((short) 6);
		
		
 		row = sheet.createRow((int) 3);
 		cell = row.createCell((short) 0);
 		cell.setCellValue("品牌");
 		cell.setCellStyle(urdStyle);
// 		cell = row.createCell((short) 1);
// 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 1);
 		cell.setCellValue("型号");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 3);
 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 2);
 		cell.setCellValue("件");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 5);
 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 3);
 		cell.setCellValue("片");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 7);
 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 4);
 		cell.setCellValue("平方");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 9);
 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 5);
 		cell.setCellValue("单价");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 11);
 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 6);
 		cell.setCellValue("金额");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 13);
 		cell.setCellStyle(urdStyle);
 		cell = row.createCell((short) 7);
 		cell.setCellValue("付款方式");
// 		cell.setCellStyle(udStyle);
// 		cell = row.createCell((short) 15);
 		cell.setCellStyle(urdStyle);
 		String money ="";
		if(bill.getMoneyType() != null && bill.getMoneyType() == 0){
			money = "未付";
		}else if(bill.getMoneyType() != null && bill.getMoneyType() == 1){
			money = "已付";
		}else if(bill.getMoneyType() != null && bill.getMoneyType() == 2){
			money = "代收";
		}else if(bill.getMoneyType() != null && bill.getMoneyType() == 3){
			money = "其他";
		}
		BigDecimal totalPrice = new BigDecimal("0");
 		for(int i=0;i<bill.getBillDetails().size()+1;i++){
 			row = sheet.createRow((int) i+4);
 			if(i ==bill.getBillDetails().size()){
 				row.setHeight((short)500);
 	 			cell = row.createCell((short) 0);
 	 	 		cell.setCellStyle(urdStyle);
// 	 	 		cell = row.createCell((short) 1);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 1);
 	 	 		cell.setCellStyle(urdStyle);
// 	 	 		cell = row.createCell((short) 3);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 2);
 	 	 		cell.setCellStyle(urdStyle);
// 	 	 		cell = row.createCell((short) 5);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 3);
 	 	 		cell.setCellStyle(urdStyle);
// 	 	 		cell = row.createCell((short) 7);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 4);
 	 	 		cell.setCellStyle(urdStyle);
// 	 	 		cell = row.createCell((short) 9);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 5);
 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell.setCellValue("合计：");
// 	 	 		cell = row.createCell((short) 11);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 6);
 	 	 		//cell.setCellValue(String.format("%.f", bd.getBillCost()));
 	 	 		cell.setCellValue(Math.rint(totalPrice.doubleValue()));
 	 	 		//cell.setCellValue(Math.rint(bd.getBillCost().doubleValue()));
 	 	 		cell.setCellStyle(urdStyle);
// 	 	 		cell = row.createCell((short) 13);
// 	 	 		cell.setCellStyle(urdStyle);
 	 	 		cell = row.createCell((short) 7);
 	 	 		cell.setCellStyle(urdStyle);
 	 	 		break;
 	 		}
 			BillDetail bd = bill.getBillDetails().get(i);
 			row = sheet.createRow((int) i+4);
 			row.setHeight((short)500);
 			Good good = bd.getGood();
 			GoodType gt = good.getGoodType();
 			cell = row.createCell((short) 0);
 	 		cell.setCellValue(gt.getName());
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 1);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 1);
 	 		cell.setCellValue(good.getName());
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 3);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 2);
 	 		cell.setCellValue(bd.getJian());
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 5);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 3);
 	 		cell.setCellValue(bd.getPian());
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 7);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 4);
 	 		cell.setCellValue(String.format("%.2f", bd.getBillCount()));
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 9);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 5);
 	 		cell.setCellValue(String.format("%.2f", bd.getBillPrice()));
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 11);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 6);
 	 		//cell.setCellValue(String.format("%.f", bd.getBillCost()));
 	 		cell.setCellValue(String.format("%.2f", bd.getBillCost()));
 	 		//cell.setCellValue(Math.rint(bd.getBillCost().doubleValue()));
 	 		cell.setCellStyle(urdStyle);
// 	 		cell = row.createCell((short) 13);
// 	 		cell.setCellStyle(urdStyle);
 	 		cell = row.createCell((short) 7);
 	 		cell.setCellValue(money);
 	 		cell.setCellStyle(urdStyle);
 	 		totalPrice = totalPrice.add(bd.getBillCost());
// 	 		cell = row.createCell((short) 15);
// 	 		cell.setCellStyle(urdStyle);
		}
// 		row = sheet.createRow((int) bill.getBillDetails().size()+3);
// 		cell = row.createCell((short) 10);
//	 	cell.setCellValue("库房电话：1234567");
//	 	cell.setCellStyle(nameStyle);
 		
 		
// 		row = sheet.createRow((int) bill.getBillDetails().size()+3);
// 		cell = row.createCell((short) 5);
//	 	cell.setCellValue("总计： ");
//	 	cell.setCellStyle(nameStyle);
//	 	cell = row.createCell((short) 6);
//	 	cell.setCellValue(Math.rint(totalPrice.doubleValue()));
//	 	cell.setCellStyle(nameStyle);
 		row = sheet.createRow((int) bill.getBillDetails().size()+5);
 		cell = row.createCell((short) 0);
	 	cell.setCellValue("注： ");
	 	cell.setCellStyle(nameStyle);
	 	cell = row.createCell((short) 1);
	 	cell.setCellValue(" 一.买方须认真点货，验货，库房默认买方已验收，不接受安装后以错误名义要求赔偿。");
	 	cell.setCellStyle(nameStyle);
	 	row = sheet.createRow((int) bill.getBillDetails().size()+6);
	 	cell = row.createCell((short) 1);
	 	cell.setCellValue("  二.处理产品不退货。部分可退货的，在购买15日内退回，散片带好包装，无包装不予退货");
	 	cell.setCellStyle(nameStyle);
	 	row = sheet.createRow((int) bill.getBillDetails().size()+7);
	 	cell = row.createCell((short) 1);
	 	cell.setCellValue("  三.运输，安装过程中，碰坏划坏等影响二次销售的，不予退货。");
	 	cell.setCellStyle(nameStyle);
	 	row = sheet.createRow((int) bill.getBillDetails().size()+8);
	 	cell = row.createCell((short) 1);
	 	cell.setCellValue("  四.现货与样板有色差，以现货为主。");
	 	cell.setCellStyle(nameStyle);
	 	HSSFCellStyle bomStyle = wb.createCellStyle();
		HSSFFont bomFont = wb.createFont();
		bomFont.setFontName(HSSFFont.FONT_ARIAL);//字体
		bomFont.setFontHeightInPoints((short) 13);//字号 
		//nameFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		bomStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT); 
		bomStyle.setFont(bomFont);
	 	row = sheet.createRow((int) bill.getBillDetails().size()+9);
	 	cell = row.createCell((short) 1);
	 	cell.setCellValue("  五.处理品不合格原因有多种,介意者慎选。建议不用在室内装修。 ");
	 	cell.setCellStyle(nameStyle);
	 	row = sheet.createRow((int) bill.getBillDetails().size()+10);
	 	cell = row.createCell((short) 0);
	 	cell.setCellValue("  本仓储直销各种品牌实木地板,多层实木地板,环保强化复合地板,抗静电地板,实木运动地板, ");
	 	cell.setCellStyle(bomStyle);
	 	row = sheet.createRow((int) bill.getBillDetails().size()+11);
	 	cell = row.createCell((short) 0);
	 	cell.setCellValue("  塑胶体育地板,个性拼花地板,防潮膜,踢脚线,护角,门口条,衣柜板材。均厂家直销 。另长期处理下线产品。 ");
	 	cell.setCellStyle(bomStyle);
	 	row = sheet.createRow((int) bill.getBillDetails().size()+12);
	 	cell = row.createCell((short) 5);
	 	cell.setCellValue("  电话：5280012");
	 	cell.setCellStyle(bomStyle);
//	 	row = sheet.createRow((int) bill.getBillDetails().size()+13);
//	 	cell = row.createCell((short) 5);
//	 	cell.setCellValue("  微信号：476067881");
//	 	cell.setCellStyle(bomStyle);
//	 	row = sheet.createRow((int) bill.getBillDetails().size()+14);
//	 	cell = row.createCell((short) 5);
//	 	cell.setCellValue("  微信号：1598455239");
//	 	cell.setCellStyle(bomStyle);
 		boolean flag = true;
		try
		{	
			Date currentTime = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			String dateString = formatter.format(currentTime);
			File file = new File("E:/xinjia/"+dateString+"/");
			if(!file.exists()){
				file.mkdirs();
			}
			FileOutputStream fout = new FileOutputStream("E:/xinjia/"+dateString+"/"+bill.getCode()+".xls");
			wb.write(fout);
			fout.close();
		}
		catch (Exception e)
		{
			flag = false;
			e.printStackTrace();
		}
		Map<String,Object> result = new HashMap<String,Object>();
		if (flag){
			result.put("success", true);
			result.put("msg", "导出成功!");
			result.put("billId", id);
		} else {
			result.put("failure", true);
			result.put("msg", "导出失败!");
		}
		return new JsonView(result);
	}
	public View getItems(int billType, BillQuery q,
			int rows, int page, String sort, String order) throws Exception{
		User user = (User)rbac.getCurrentUser();
		
		String orderBy = "id desc";
		if (sort != null && order != null){
			orderBy = sort + " " + order;
		}
		String cond = "billType=" + billType;
		List<Object> tmpArgs = new ArrayList<Object>();
		List<Good> goodList = new ArrayList<Good>();
		List<BillDetail> billList = new ArrayList<BillDetail>();
		boolean flag = false;
		if (q != null){
			if (q.getCode() != null && !q.getCode().trim().equals("")){
				cond += " and (code like ?)";
				tmpArgs.add("%" + q.getCode().trim() + "%");
			}
			if (q.getCodeFrom() != null && !q.getCodeFrom().trim().equals("")){
				cond += " and code>=?";
				tmpArgs.add(q.getCodeFrom().trim());
			}
			if (q.getCodeTo() != null && !q.getCodeTo().trim().equals("")){
				cond += " and code<=?";
				tmpArgs.add(q.getCodeTo().trim());
			}
			if (q.getDateFrom() != null && !q.getDateFrom().trim().equals("")){
				cond += " and billDate>=?";
				tmpArgs.add(q.getDateFrom().trim());
			}
			if (q.getDateTo() != null && !q.getDateTo().trim().equals("")){
				cond += " and billDate<=?";
				tmpArgs.add(q.getDateTo().trim());
			}
			if (q.getIntercourseId() != null){
				cond += " and intercourseId=?";
				tmpArgs.add(q.getIntercourseId());
			}
			if (q.getDepotId() != null){
				cond += " and depotId=?";
				tmpArgs.add(q.getDepotId());
			}
			if (q.getDepot2Id() != null){
				cond += " and depot2Id=?";
				tmpArgs.add(q.getDepot2Id());
			}
			if (q.getWorkerId() != null){
				cond += " and workerId=?";
				tmpArgs.add(q.getWorkerId());
			}
			if (q.getStockType() != null){
				cond += " and stockType=?";
				tmpArgs.add(q.getStockType());
			}
			if (q.getShWorker() != null && !q.getShWorker().trim().equals("")){
				cond += " and shWorker like ?";
				tmpArgs.add("%" + q.getShWorker() + "%");
			}
			if (q.getMoneyType() != null){
				cond += " and moneyType=?";
				tmpArgs.add(q.getMoneyType());
			}
			if (q.getGoodType() != null && !q.getGoodType().trim().equals("")){
				//cond += " and shWorker like ?";
				//tmpArgs.add("%" + q.getShWorker() + "%");
				flag = true;
				String goodCond = "1=1";
				List<Object> goodArgs = new ArrayList<Object>();
				goodCond += " and (name like ?)";
				goodArgs.add("%"+q.getGoodType()+"%");
				String goodOrderBy = "id";
				goodList = Good.findAll(Good.class, goodCond, goodArgs.toArray(), goodOrderBy, Integer.MAX_VALUE, 0);
				if(goodList.size()>0){
					for(Good good: goodList){
						List<Object> billArgs = new ArrayList<Object>();
						List<BillDetail> tempList = new ArrayList<BillDetail>();
						billArgs.add(good.getId());
						tempList = BillDetail.findAll(BillDetail.class, " (goodId = ?)", billArgs.toArray(), "id", Integer.MAX_VALUE, 0);
						billList.addAll(tempList);
					}
				}
			}
		}
		Object[] args = tmpArgs.toArray();
		
		long total = Bill.count(Bill.class, cond, args);	// 查询到的记录数
		BigDecimal  billCost = new BigDecimal(0);
		BigDecimal  workerCost = new BigDecimal(0);
		BigDecimal billCount = new BigDecimal("0");
		List<Map<String,Object>> items = new ArrayList<Map<String,Object>>();
		List<Bill> billListShow = new ArrayList<Bill>();
		if(flag){
			cond = cond +" and (1!=1 ";
			List<Object> tmpArgsXh = new ArrayList<Object>();
			for(BillDetail detail:billList){
				cond = cond + " or id = ? ";
				tmpArgs.add(detail.getBillId());
			}
			cond = cond +" )";
			total = Bill.count(Bill.class, cond, tmpArgs.toArray());
			billListShow = Bill.findAll(Bill.class, cond, tmpArgs.toArray(), orderBy, rows, (page-1)*rows);
			//total = billListShow.size();
		}else{
			billListShow = Bill.findAll(Bill.class, cond, args, orderBy, rows, (page-1)*rows);
		}

		for(Bill bill: billListShow){
			Map<String,Object> item = new HashMap<String,Object>();
			item.put("id", bill.getId());
			item.put("code", bill.getCode());
			item.put("billDate", bill.getBillDate());
			item.put("status", bill.getStatus());
			item.put("workerPrice", bill.getWorkerPrice());
			if (bill.getIntercourse() != null){
				item.put("intercourseName", bill.getIntercourse().getShortName());
			}
			if (bill.getDepot() != null){
				item.put("depotName", bill.getDepot().getName());
			}
			if (bill.getDepot2() != null){
				item.put("depot2Name", bill.getDepot2().getName());
			}
			if (bill.getWorker() != null){
				item.put("workerName", bill.getWorker().getName());
			}
			item.put("remark", bill.getRemark());
			item.put("billCount", bill.getBillCount());
			item.put("billCost", bill.getBillCost());
			item.put("shWorker", bill.getShWorker());
			String money ="";
			if(bill.getMoneyType() != null && bill.getMoneyType() == 0){
				money = "未付";
			}else if(bill.getMoneyType() != null && bill.getMoneyType() == 1){
				money = "已付";
			}else if(bill.getMoneyType() != null && bill.getMoneyType() == 2){
				money = "代收";
			}else if(bill.getMoneyType() != null && bill.getMoneyType() == 3){
				money = "其他";
			}
			item.put("moneyType", money);
			// 确定该单据是否可编辑
			if (bill.getStatus() == 0 && bill.getWriteUserId() == user.getId().intValue()){
				item.put("editable", true);
			} else {
				item.put("editable", false);
			}
			billCost = billCost.add(bill.getBillCost()== null?new BigDecimal(0):bill.getBillCost());
			workerCost = workerCost.add(bill.getWorkerPrice() == null?new BigDecimal(0):bill.getWorkerPrice());
			if (bill.getBillCount() == null){
				billCount = billCount.add(new BigDecimal("0"));
			}else{
				billCount = billCount.add(bill.getBillCount());
			}
			items.add(item);
		}
		List<Map<String,Object>> footer = new ArrayList<Map<String,Object>>();
		Map<String,Object> fitem = new HashMap<String,Object>();
		fitem.put("code", "合计");
		fitem.put("billCount", billCount);
		fitem.put("billCost", billCost);
		fitem.put("workerPrice", workerCost);
		footer.add(fitem);
		Map<String,Object> result = new HashMap<String,Object>();
		result.put("total", total);
		result.put("rows", items);
		result.put("footer", footer);
		return new JsonView(result);
	}
	
	public void create() throws Exception{
		Bill bill = new Bill();
		bill.setCode("单据编号由系统自动生成");
		bill.setBillDate(new java.sql.Date(System.currentTimeMillis()));
		request.setAttribute("editable", true);
		request.setAttribute("checkable", false);
		request.setAttribute("bill", bill);
		request.setAttribute("detailUrl", "/bill/getInitDetails");
	}
	
	public void edit(int id) throws Exception{
		User user = (User)rbac.getCurrentUser();
		Bill bill = Bill.find(Bill.class, id);
		if (bill.getStatus() == 0 && bill.getWriteUserId() == user.getId().intValue()){
			request.setAttribute("editable", true);
		}
		if (bill.getStatus() == 0){
			request.setAttribute("checkable", true);
		}
		request.setAttribute("bill", bill);
		request.setAttribute("detailUrl", "/bill/getBillDetails?billId="+bill.getId());
	}
	
	public View checkBill(int id) throws Exception{
		User user = (User)rbac.getCurrentUser();
		String ok = CheckService.checkBill(id, user.getId());
		Map<String,Object> result = new HashMap<String,Object>();
		if (ok.equals("ok")){
			result.put("success", true);
			result.put("billId", id);
			result.put("msg", ok);
		} else {
			result.put("failure", true);
			result.put("msg", ok);
		}
		return new JsonView(result);
	}
	
	public View destroy(int id) throws Exception{
		User user = (User)rbac.getCurrentUser();
		
		Map<String,Object> result = new HashMap<String,Object>();
		Bill item = Bill.find(Bill.class, id);
		if (item.getStatus() == 0){
			if (item.getWriteUserId() != user.getId().intValue()){
				result.put("failure", true);
				result.put("msg", "对不起，你没有权限删除该单据。");
			} else {
				item.destroy();
				result.put("success", true);
			}
		} else {
			result.put("failure", true);
			result.put("msg", "该单据已经审核，不能删除。");
		}
		return new JsonView(result);
	}
	
	protected Map<String,Object> saveBill(Bill item, String goods) throws Exception{
		Map<String,Object> result = new HashMap<String,Object>();
		try{
			Bill.beginTransaction();
			
			if (item.getId() == null){
				switch(item.getBillType().intValue()){
					case 1:
						item.setCode(Bill.nextCode("RM"));
						break;
					case 11:
						item.setCode(Bill.nextCode("RP"));
						break;
					case 2:
						item.setCode(Bill.nextCode("SM"));
						break;
					case 3:
						item.setCode(Bill.nextCode("TR"));
						break;
				}
				item.save();
			}
			
			BillDetail.deleteAll(BillDetail.class, "billId=?", new Object[]{item.getId()});
			if (goods != null && !goods.trim().equals("")){
				BigDecimal count = new BigDecimal("0");
				BigDecimal cost = new BigDecimal(0);
				String[] rows = goods.trim().split(",");
				for(String row: rows){
					String[] fields = row.split(":");
					BillDetail detail = new BillDetail();
					detail.setBillId(item.getId());
					detail.setGoodId(Integer.parseInt(fields[0]));
					detail.setBillCount(new BigDecimal(fields[1]));
					detail.setBillPrice(new BigDecimal(fields[2]));
					detail.setJian(Integer.parseInt(fields[3]));
					detail.setPian(Integer.parseInt(fields[4]));
					if (fields.length>=6){
						detail.setBillDetailId(Integer.valueOf(fields[5]));
					}
					detail.save();
					
					count = count.add(detail.getBillCount());
					cost = cost.add(detail.getBillPrice().multiply(detail.getBillCount()));
				}
				item.setBillCount(count);
				item.setBillCost(cost);
				item.save();
			} else {
				item.save();
			}
			
			Bill.commit();
			result.put("success", true);
			result.put("billId", item.getId());
		} catch(Exception ex){
			ex.printStackTrace();
			Bill.rollback();
			result.put("failure", true);
			result.put("msg", "单据保存过程出现错误：" + ex.getMessage());
		}
		return result;
	}
	public static void main(String[] args) {
		System.out.println(Math.rint(2.21));
		System.out.println(Math.rint(2.91444));
		System.out.println(Math.rint(2.112222));
		System.out.println(Math.rint(2.19666));
		//System.out.println(String.format("%.2f", 2.19666););
	}

}
