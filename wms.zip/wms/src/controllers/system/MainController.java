package controllers.system;

import controllers.ApplicationController;

public class MainController extends ApplicationController {
	public void index(){
		
	}
}
